<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('DB_HOST', 'localhost');
define('DB_NAME', 'student_db');
define('DB_USER', 'root');   
define('DB_PASS', '');       

// Sign-up page: let the person pick their user type (Admin, Registrar, Dean, Instructor, Student).
// Turn this OFF (false) once your test accounts are created. When false, every sign-up is a Student.
define('ALLOW_ROLE_SELECTION_ON_SIGNUP', true);

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
